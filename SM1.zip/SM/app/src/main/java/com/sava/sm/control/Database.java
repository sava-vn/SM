package com.sava.sm.control;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.sava.sm.model.MyNote;

import java.util.ArrayList;

/**
 * Created by Mr.Sang on 1/20/2018.
 */

public class Database extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "MY_DATA";
    private static final String TABLE_NOTE = "NOTE";
    private static final String ID_NOTE = "idNote";
    private static final String TITLE_NOTE = "title_note";
    private static final String CONTENT_NOTE = "content_note";
    private static final String DATE_NOTE = "date_note";
    private static final String STATUS_NOTE = "status_note";
    private static final int VERSION = 1;
    private Context context;

    private String createTableNote = "Create Table " +
            TABLE_NOTE + " ( " +
            ID_NOTE + " integer primary key , " +
            TITLE_NOTE + " text, " +
            CONTENT_NOTE + " text , " +
            DATE_NOTE + " text , " +
            STATUS_NOTE + " int )";

    public Database(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(createTableNote);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addNote(MyNote myNote) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TITLE_NOTE, myNote.getmTitle());
        values.put(CONTENT_NOTE, myNote.getmContent());
        values.put(DATE_NOTE, myNote.getmDate());
        values.put(STATUS_NOTE, myNote.isStatus() ? 1 : 0);
        db.insert(TABLE_NOTE, null, values);
        db.close();
    }

    public ArrayList<MyNote> getAllNote() {
        ArrayList<MyNote> list = new ArrayList<>();
        String query = "SELECT * FROM  " + TABLE_NOTE;
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                MyNote myNote = new MyNote();
                myNote.setmID(cursor.getInt(0));
                myNote.setmTitle(cursor.getString(1));
                myNote.setmContent(cursor.getString(2));
                myNote.setmDate(cursor.getString(3));
                myNote.setStatus(cursor.getInt(4) == 1 ? true : false);
                list.add(myNote);
            } while (cursor.moveToNext());
            db.close();
        }
        return list;
    }

    public ArrayList<MyNote> getAllNoteStar() {
        ArrayList<MyNote> list = new ArrayList<>();
        String query = "SELECT * FROM  " + TABLE_NOTE  + " WHERE " + STATUS_NOTE + " = 1";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                MyNote myNote = new MyNote();
                myNote.setmID(cursor.getInt(0));
                myNote.setmTitle(cursor.getString(1));
                myNote.setmContent(cursor.getString(2));
                myNote.setmDate(cursor.getString(3));
                myNote.setStatus(true);
                list.add(myNote);
            } while (cursor.moveToNext());
            db.close();
        }
        return list;
    }

    public void deleteNote(MyNote myNote) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NOTE, ID_NOTE + " = ?", new String[]{String.valueOf(myNote.getmID())});
        db.close();
    }

    public int updateNote(MyNote myNote) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TITLE_NOTE, myNote.getmTitle());
        values.put(CONTENT_NOTE, myNote.getmContent());
        values.put(DATE_NOTE, myNote.getmDate());
        values.put(STATUS_NOTE, myNote.isStatus() ? 1 : 0);
        return db.update(TABLE_NOTE, values, ID_NOTE + " = ? ", new String[]{String.valueOf(myNote.getmID())});
    }

    public int updateNoteStatus(MyNote myNote) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(STATUS_NOTE, myNote.isStatus() ? 1 : 0);
        return db.update(TABLE_NOTE, values, ID_NOTE + " = ? ", new String[]{String.valueOf(myNote.getmID())});
    }

    public void deleteList(ArrayList<MyNote> listDelete) {
        for (MyNote myNote : listDelete)
            deleteNote(myNote);
        listDelete.clear();
    }
}

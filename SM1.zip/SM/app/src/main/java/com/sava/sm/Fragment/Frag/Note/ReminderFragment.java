package com.sava.sm.Fragment.Frag.Note;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.sava.sm.R;
import com.sava.sm.adapter.ReminderAdpater;
import com.sava.sm.itf.RecyclerViewClickListener;
import com.sava.sm.model.Reminder;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Mr.Sang on 2/5/2018.
 */

public class ReminderFragment extends Fragment implements TimePickerDialog.OnTimeSetListener ,DatePickerDialog.OnDateSetListener {
    private ReminderAdpater mReminderAdpater;
    private ArrayList<Reminder> mList;
    private RecyclerView mRecyclerView;
    private Date dateSelect;
    private Calendar calendarSelect;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reminder,container,false);
        initWidget(view);
        return view;
    }
    public void initWidget(View view){
        mList = new ArrayList<>();
        mList.add(new Reminder());
        mList.add(new Reminder());
        mList.add(new Reminder());
        mList.add(new Reminder());
        mList.add(new Reminder());
        mRecyclerView =view.findViewById(R.id.rv_reminder);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(),LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(layoutManager);
        mReminderAdpater = new ReminderAdpater(getActivity(), mList, new RecyclerViewClickListener() {
            @Override
            public void onClick(View view, int position) {
                Calendar now = Calendar.getInstance();
                DatePickerDialog  datePickerDialog = DatePickerDialog.newInstance(
                        ReminderFragment.this,
                        now.get(Calendar.YEAR),
                        now.get(Calendar.MONTH),
                        now.get(Calendar.DAY_OF_MONTH)
                );
                datePickerDialog.setVersion(DatePickerDialog.Version.VERSION_1);
                datePickerDialog.show(getActivity().getFragmentManager(),"SAVALE");
            }
        });
        mRecyclerView.setAdapter(mReminderAdpater);
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        dateSelect = new Date();
        calendarSelect  = Calendar.getInstance();
        calendarSelect.set(year,monthOfYear,dayOfMonth);
        TimePickerDialog timePickerDialog = TimePickerDialog.newInstance(
                ReminderFragment.this,
                calendarSelect.get(Calendar.HOUR_OF_DAY),
                calendarSelect.get(Calendar.MINUTE),
                true
        );
        timePickerDialog.show(getActivity().getFragmentManager(),"Time");
    }

    @Override
    public void onTimeSet(TimePickerDialog view, int hourOfDay, int minute, int second) {
        calendarSelect.set(Calendar.HOUR_OF_DAY,hourOfDay);
        calendarSelect.set(Calendar.MINUTE,minute);
        dateSelect = calendarSelect.getTime();
        String s = (String) android.text.format.DateFormat.format("dd-MM-yyyy HH:mm",dateSelect);
        Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
    }
}
